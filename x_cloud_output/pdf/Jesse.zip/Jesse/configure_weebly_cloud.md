## Brand Sites and the Cloud Admin

You can brand Weebly Cloud by adding your company's name and uploading your company's logo and a fav icon. Once configured, your company's name displays in a number of places, such as the footer of published sites, in the Site Editor, and in invitaiton emails.

For example, here's the footer of a published site showing the company name Nash Hosting.
{% include image.html file=”.png” %} [[Insert necessary image here]]
And here's an email sent inviting a new user.
{% include image.html file=”.png” %} [[Insert necessary image here]]
​Once uploaded, the logo displays in the Cloud Admin as shown here:
{% include image.html file=”.png” %} [[Insert necessary image here]]
To brand sites and the Cloud Admin<span style="color: red">[[URL: admin]]</span>, from the **Settings** tab, click the **Edit** icon and enter the company name and upload the needed files.
{% include image.html file=”.png” %} [[Insert necessary image here]]
***

## Set  Your Domain
You can set a domain that is used to access both the Cloud Admin (<domain>/admin) and the User portal (**<domain>**/portal), and that displays in the user's address bar when using the Site Editor. You can choose to use a subdomain of **weeblycloud.com** or you can use a custom domian.
{% include note.html content="If you don't configure a domain, you will not be able to generate and send emails from the Cloud Admin and you will not have access to the User portal." %}